#!/bin/bash
/usr/bin/supervisord
